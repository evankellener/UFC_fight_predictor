UFC News Features Pipeline - v1

Files:
1) news_discovery.py
   - Finds recent articles for given fighters using Google News RSS and site RSS.
   - Filters by date window.
   - Writes discovery_results.csv

2) news_fetch_parse.py
   - Async fetcher that downloads and parses article text.
   - Extracts publish dates from meta tags when possible.
   - Adds quick heuristic hit counts for short notice, injury, and camp mentions.
   - Writes articles_parsed.parquet and articles_parsed.csv

3) feature_scoring.py
   - Aggregates parsed articles into the 4 final features per fighter
   - Writes features_final.csv

4) run_news_pipeline.py
   - CLI wrapper to run discovery then fetch-parse in one command.

Quick start
-----------
1) Create and activate a virtualenv.
2) pip install -r requirements.txt  (see below)
3) Run the full pipeline example:

python run_news_pipeline.py   --fighters "Dominick Reyes;Carlos Ulberg"   --opponent_pairs "Dominick Reyes|Carlos Ulberg;Carlos Ulberg|Dominick Reyes"   --event_date 2025-09-27   --days_back 60   --outdir ./out

Inputs
------
- --fighters: semicolon separated fighter names
- --opponent_pairs: semicolon separated pairs formatted as Fighter|Opponent
  The i-th fighter in --fighters should correspond to the i-th pair here.
  If you only have fighters and a shared opponent, you can pass just the fighters
  and skip this flag. The fetcher will still work.

- --event_date: YYYY-MM-DD date of the event
- --days_back: how many days before event_date to search

Outputs
-------
- discovery_results.csv
  Columns: fighter, opponent, event_date, source_domain, title, url, published

- articles_parsed.parquet and articles_parsed.csv
  Columns include: fighter, opponent, url, title, published, fetched_published,
  source_domain, text_len, short_notice_hits, injury_hits, camp_pos_hits, camp_neg_hits, text

Requirements
-----------
feedparser
requests
beautifulsoup4
aiohttp
pandas
pyarrow  (for parquet, optional but recommended)
python-dateutil
tqdm
lxml

Optional
--------
readability-lxml or trafilatura can improve text extraction. The default uses BeautifulSoup only.

Notes
-----
- Google News RSS does not guarantee strict date filtering, so we filter after fetching.
- Respect robots.txt and site terms. Add rate limits as needed.
- You can extend SITE_RSS and SOURCE_CRED maps in the scripts.
