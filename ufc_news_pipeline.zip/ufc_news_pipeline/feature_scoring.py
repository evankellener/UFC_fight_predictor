#!/usr/bin/env python3
import argparse
import pandas as pd
from datetime import datetime, timezone
from dateutil import parser as dateparser
import math
import re

def parse_dt(s):
    if not s or not isinstance(s, str):
        return None
    try:
        return dateparser.parse(s)
    except Exception:
        return None

def days_between(later_date, earlier_date):
    try:
        return max(0, (later_date.date() - earlier_date.date()).days)
    except Exception:
        return None

def compute_features(df: pd.DataFrame, event_date_str: str, days_back: int):
    event_dt = dateparser.parse(event_date_str)
    if event_dt.tzinfo is None:
        event_dt = event_dt.replace(tzinfo=timezone.utc)

    # Normalize publish date per row
    pub_cols = ["fetched_published", "published"]
    def row_pub_dt(row):
        for c in pub_cols:
            dt = parse_dt(row.get(c, ""))
            if dt:
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return dt
        return None

    df = df.copy()
    df["pub_dt"] = df.apply(row_pub_dt, axis=1)
    # recency weight relative to event-date
    def recency_w(dt):
        if not dt:
            return 0.5
        days_to_event = max(0, (event_dt.date() - dt.date()).days)
        # decay to prefer recent - within 60 days is typical, lambda 0.05
        return math.exp(-0.05 * days_to_event)

    df["w"] = df["pub_dt"].apply(recency_w)

    results = []
    for (fighter, opponent), sub in df.groupby(["fighter", "opponent"], dropna=False):
        sub = sub.reset_index(drop=True)

        # Short notice flag and announcement date
        sn_rows = sub[sub["short_notice_hits"] > 0]
        short_notice = 1 if len(sn_rows) > 0 else 0

        # Choose announcement date:
        ann_dt = None
        if short_notice and len(sn_rows) > 0:
            # earliest article that triggered short notice
            ann_dt = min([d for d in sn_rows["pub_dt"].tolist() if d] or [None], default=None)
        if ann_dt is None:
            # try article that mentions vs plus opponent
            try_rows = sub[sub["title"].fillna("").str.contains(r"\bvs\b", case=False) |
                           sub["text"].fillna("").str.contains(r"\bvs\b", case=False)]
            if isinstance(opponent, str) and opponent:
                pat = re.compile(re.escape(opponent), flags=re.I)
                try_rows = try_rows[try_rows["text"].fillna("").str.contains(pat) |
                                    try_rows["title"].fillna("").str.contains(pat)]
            ann_dt = min([d for d in try_rows["pub_dt"].tolist() if d] or [None], default=None)
        if ann_dt is None:
            # fallback earliest publish among all rows
            ann_dt = min([d for d in sub["pub_dt"].tolist() if d] or [None], default=None)
        if ann_dt is None:
            # absolute fallback: event_date minus days_back
            ann_dt = event_dt - pd.Timedelta(days=days_back)

        short_notice_duration_days = days_between(event_dt, ann_dt)

        # Injury risk 0 to 10
        # Weighted average of injury_hits then scaled
        num = float((sub["injury_hits"] * sub["w"]).sum())
        den = float(sub["w"].sum()) if float(sub["w"].sum()) > 0 else 1.0
        injury_avg = num / den
        injury_risk = int(max(0, min(10, round(min(5.0, injury_avg) * 2))))  # cap average at 5 hits - maps to 10

        # Camp status 1 to 10
        # Weighted average of (pos - neg)
        camp_num = float(((sub["camp_pos_hits"] - sub["camp_neg_hits"]) * sub["w"]).sum())
        camp_den = den
        camp_signal = camp_num / camp_den
        camp_status = int(max(1, min(10, round(5 + 1.5 * camp_signal))))  # neutral is 5

        results.append({
            "fighter": fighter,
            "opponent": opponent,
            "event_date": event_dt.date().isoformat(),
            "short_notice": int(short_notice),
            "short_notice_duration_days": int(short_notice_duration_days if short_notice_duration_days is not None else 0),
            "injury_risk_0to10": injury_risk,
            "camp_status_1to10": camp_status,
            "n_articles": int(len(sub))
        })
    return pd.DataFrame(results)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_csv", required=True, help="articles_parsed.csv path")
    ap.add_argument("--event_date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--days_back", type=int, default=60)
    ap.add_argument("--out_csv", default="features_final.csv")
    args = ap.parse_args()

    df = pd.read_csv(args.in_csv)
    features = compute_features(df, args.event_date, args.days_back)
    features.to_csv(args.out_csv, index=False)
    print(f"Wrote {len(features)} rows to {args.out_csv}")

if __name__ == "__main__":
    main()
