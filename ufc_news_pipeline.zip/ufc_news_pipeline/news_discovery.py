#!/usr/bin/env python3
import argparse
import csv
import re
import sys
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus, urlparse
import requests
import feedparser
from dateutil import parser as dateparser

SITE_RSS = {
    "mmafighting.com": "https://www.mmafighting.com/rss/current",
    "mmajunkie.usatoday.com": "https://mmajunkie.usatoday.com/feed",
    "sherdog.com": "https://www.sherdog.com/rss/news.xml",
    "espn.com": "https://www.espn.com/espn/rss/mma/news",
    "thebodylockmma.com": "https://thebodylockmma.com/feed/",
}

def google_news_rss_query(query: str) -> str:
    q = quote_plus(query)
    return f"https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en"

def extract_domain(url: str) -> str:
    try:
        dom = urlparse(url).netloc.lower()
        return dom[4:] if dom.startswith("www.") else dom
    except Exception:
        return ""

def inside_window(dt, start, end) -> bool:
    if not dt:
        return False
    return start <= dt <= end

def fetch_feed(url: str):
    try:
        return feedparser.parse(url)
    except Exception:
        return {"entries": []}

def parse_entry(entry):
    title = entry.get("title", "").strip()
    link = entry.get("link", "").strip()
    dt = None
    for key in ["published", "pubDate", "updated"]:
        v = entry.get(key)
        if v:
            try:
                dt = dateparser.parse(v)
                break
            except Exception:
                pass
    return title, link, dt

def discover_for_fighter(name: str, opponent: str, event_date: datetime, days_back: int):
    end = datetime.combine(event_date, datetime.min.time(), tzinfo=timezone.utc)
    start = end - timedelta(days=days_back)
    seen = set()
    rows = []

    queries = [
        f'"{name}" UFC',
        f'"{name}" interview',
        f'"{name}" injury',
        f'"{name}" training camp',
        f'"{name}" vs "{opponent}"',
    ]
    for q in queries:
        rss_url = google_news_rss_query(q)
        feed = fetch_feed(rss_url)
        for e in feed.get("entries", []):
            title, link, dt = parse_entry(e)
            if not link or not title:
                continue
            if dt and dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if not inside_window(dt, start, end):
                continue
            key = (title, link)
            if key in seen:
                continue
            seen.add(key)
            rows.append({
                "fighter": name,
                "opponent": opponent,
                "event_date": event_date.date().isoformat(),
                "source_domain": extract_domain(link),
                "title": title,
                "url": link,
                "published": dt.isoformat() if dt else ""
            })

    for dom, rss in SITE_RSS.items():
        feed = fetch_feed(rss)
        for e in feed.get("entries", []):
            title, link, dt = parse_entry(e)
            if not link or not title:
                continue
            text = f"{title} {e.get('summary','')}"
            if re.search(rf"\b{re.escape(name)}\b", text, flags=re.I):
                if dt and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if not inside_window(dt, start, end):
                    continue
                key = (title, link)
                if key in seen:
                    continue
                seen.add(key)
                rows.append({
                    "fighter": name,
                    "opponent": opponent,
                    "event_date": event_date.date().isoformat(),
                    "source_domain": extract_domain(link) or dom,
                    "title": title,
                    "url": link,
                    "published": dt.isoformat() if dt else ""
                })
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fighters", required=True, help="Semicolon separated fighter names")
    ap.add_argument("--opponent_pairs", default="", help="Semicolon separated Fighter|Opponent pairs")
    ap.add_argument("--event_date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--days_back", type=int, default=60)
    ap.add_argument("--out_csv", default="discovery_results.csv")
    args = ap.parse_args()

    event_date = dateparser.parse(args.event_date).date()
    fighters = [s.strip() for s in args.fighters.split(";") if s.strip()]
    opp_pairs = []
    if args.opponent_pairs:
        for p in args.opponent_pairs.split(";"):
            if "|" in p:
                a,b = p.split("|", 1)
                opp_pairs.append((a.strip(), b.strip()))
    opponents = []
    for f in fighters:
        opp = ""
        for a,b in opp_pairs:
            if a.lower() == f.lower():
                opp = b
                break
        opponents.append(opp)

    all_rows = []
    for f,opp in zip(fighters, opponents):
        rows = discover_for_fighter(f, opp, datetime(event_date.year, event_date.month, event_date.day, tzinfo=timezone.utc), args.days_back)
        all_rows.extend(rows)

    seen = set()
    deduped = []
    for r in all_rows:
        key = (r["fighter"].lower(), r["url"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)

    with open(args.out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["fighter","opponent","event_date","source_domain","title","url","published"])
        w.writeheader()
        w.writerows(deduped)
    print(f"Wrote {len(deduped)} rows to {args.out_csv}")

if __name__ == "__main__":
    main()
