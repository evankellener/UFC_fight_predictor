#!/usr/bin/env python3
import argparse
import asyncio
import aiohttp
from aiohttp import ClientTimeout
from bs4 import BeautifulSoup
import pandas as pd
from urllib.parse import urlparse
from dateutil import parser as dateparser
from datetime import datetime, timezone
import re
import os
from tqdm import tqdm

INJURY_KEYWORDS = [
    "injury", "injured", "surgery", "withdraw", "illness", "hamstring",
    "knee", "elbow", "broken", "torn", "fracture", "tear", "pulled out"
]
SHORT_NOTICE_PHRASES = [
    "short notice", "late replacement", "stepped in", "replacement", "called up", "pulled from the card", "pulled from card"
]
CAMP_POSITIVE = ["good camp", "great camp", "prepared", "in great shape", "peaking", "confident", "sharp", "smooth camp"]
CAMP_NEGATIVE = ["struggling in camp", "had trouble in camp", "weight cut issues", "cutting issues", "missed weight", "camp issues", "bad camp"]

def extract_domain(url: str) -> str:
    try:
        dom = urlparse(url).netloc.lower()
        return dom[4:] if dom.startswith("www.") else dom
    except Exception:
        return ""

def parse_meta_date(soup: BeautifulSoup):
    meta_names = [
        ("meta", "property", "article:published_time"),
        ("meta", "name", "pubdate"),
        ("meta", "name", "publishdate"),
        ("meta", "name", "date"),
        ("meta", "itemprop", "datePublished"),
        ("meta", "property", "og:published_time"),
        ("time", "datetime", None),
    ]
    for tag, attr, val in meta_names:
        el = None
        if tag == "time":
            el = soup.find("time", attrs={"datetime": True})
            if el and el.get("datetime"):
                try:
                    return dateparser.parse(el.get("datetime"))
                except Exception:
                    pass
        else:
            el = soup.find(tag, attrs={attr: val}) if val else soup.find(tag, attrs={attr: True})
            if el:
                content = el.get("content") or el.get("datetime")
                if content:
                    try:
                        return dateparser.parse(content)
                    except Exception:
                        continue
    return None

def clean_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    for t in soup(["script","style","noscript","header","footer","svg"]):
        t.decompose()
    paras = [p.get_text(" ", strip=True) for p in soup.find_all("p")]
    txt = " ".join(paras)
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt

async def fetch_one(session: aiohttp.ClientSession, row, sem, timeout):
    url = row["url"]
    async with sem:
        try:
            async with session.get(url, timeout=timeout, headers={"User-Agent": "mma-news-bot/0.1"}) as resp:
                if resp.status != 200:
                    return None
                html = await resp.text()
        except Exception:
            return None
    text = clean_text(html)
    soup = BeautifulSoup(html, "lxml")
    title = soup.find("title").get_text(strip=True) if soup.find("title") else row.get("title","")
    meta_dt = parse_meta_date(soup)
    head = (title or "") + " " + text[:800]
    short_hits = sum(1 for p in SHORT_NOTICE_PHRASES if re.search(r"\b" + re.escape(p) + r"\b", head, flags=re.I))
    injury_hits = sum(len(re.findall(r"\b" + re.escape(k) + r"\b", text, flags=re.I)) for k in INJURY_KEYWORDS)
    camp_pos_hits = sum(len(re.findall(re.escape(k), text, flags=re.I)) for k in CAMP_POSITIVE)
    camp_neg_hits = sum(len(re.findall(re.escape(k), text, flags=re.I)) for k in CAMP_NEGATIVE)

    return {
        "fighter": row.get("fighter",""),
        "opponent": row.get("opponent",""),
        "url": url,
        "source_domain": row.get("source_domain") or extract_domain(url),
        "title": title,
        "published": row.get("published",""),
        "fetched_published": meta_dt.isoformat() if meta_dt else "",
        "text_len": len(text),
        "short_notice_hits": short_hits,
        "injury_hits": injury_hits,
        "camp_pos_hits": camp_pos_hits,
        "camp_neg_hits": camp_neg_hits,
        "text": text,
    }

async def run_fetch(csv_path: str, out_parquet: str, out_csv: str, max_concurrency: int = 8):
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=["url"])
    sem = asyncio.Semaphore(max_concurrency)
    timeout = aiohttp.ClientTimeout(total=20)
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_one(session, r._asdict(), sem, timeout) for r in df.itertuples(index=False)]
        out = []
        for f in tqdm(asyncio.as_completed(tasks), total=len(tasks)):
            res = await f
            if res:
                out.append(res)
    if not out:
        print("No articles fetched")
        return
    out_df = pd.DataFrame(out)
    try:
        out_df.to_parquet(out_parquet, index=False)
        print(f"Wrote {len(out_df)} rows to {out_parquet}")
    except Exception as e:
        print(f"Parquet write failed: {e}")
    out_df.to_csv(out_csv, index=False)
    print(f"Wrote {len(out_df)} rows to {out_csv}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_csv", required=True, help="discovery_results.csv")
    ap.add_argument("--out_parquet", default="articles_parsed.parquet")
    ap.add_argument("--out_csv", default="articles_parsed.csv")
    ap.add_argument("--max_concurrency", type=int, default=8)
    args = ap.parse_args()
    asyncio.run(run_fetch(args.in_csv, args.out_parquet, args.out_csv, args.max_concurrency))

if __name__ == "__main__":
    main()
