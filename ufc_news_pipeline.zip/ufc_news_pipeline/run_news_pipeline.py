#!/usr/bin/env python3
import argparse
import os
import subprocess

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fighters", required=True, help="Semicolon separated fighter names")
    ap.add_argument("--opponent_pairs", default="", help="Semicolon separated Fighter|Opponent pairs")
    ap.add_argument("--event_date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--days_back", type=int, default=60)
    ap.add_argument("--outdir", default="./out")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    discovery_csv = os.path.join(args.outdir, "discovery_results.csv")
    parsed_parquet = os.path.join(args.outdir, "articles_parsed.parquet")
    parsed_csv = os.path.join(args.outdir, "articles_parsed.csv")

    cmd1 = [
        "python", "news_discovery.py",
        "--fighters", args.fighters,
        "--event_date", args.event_date,
        "--days_back", str(args.days_back),
        "--out_csv", discovery_csv
    ]
    if args.opponent_pairs:
        cmd1.extend(["--opponent_pairs", args.opponent_pairs])
    print("Running discovery:", " ".join(cmd1))
    subprocess.check_call(cmd1)

    cmd2 = [
        "python", "news_fetch_parse.py",
        "--in_csv", discovery_csv,
        "--out_parquet", parsed_parquet,
        "--out_csv", parsed_csv
    ]
    print("Running fetch-parse:", " ".join(cmd2))
    subprocess.check_call(cmd2)

    # Run feature scoring
    features_csv = os.path.join(args.outdir, "features_final.csv")
    cmd3 = [
        "python", "feature_scoring.py",
        "--in_csv", parsed_csv,
        "--event_date", args.event_date,
        "--days_back", str(args.days_back),
        "--out_csv", features_csv
    ]
    print("Running feature scoring:", " ".join(cmd3))
    subprocess.check_call(cmd3)
    print("Done. Outputs written to", args.outdir)

if __name__ == "__main__":
    main()
